package mybatis;

import java.io.*;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import member.dto.MemberDTO;

public class MemberMapper {
	private static SqlSessionFactory sqlMapper;
	
	static{
		try{
			String resource = "mybatis/configuration.xml";
			Reader reader = Resources.getResourceAsReader(resource);
			sqlMapper = new SqlSessionFactoryBuilder().build(reader);
		}catch(IOException e){
			throw new RuntimeException
			("myBatis�� ���������� �ø��µ� �����Ͽ����ϴ�." + e, e);
		}
	}
	
	public static List<MemberDTO> listMember(){
		SqlSession session = sqlMapper.openSession();
		try{
			List<MemberDTO> list = session.selectList("listMember");
			return list;
		}finally{
			session.close();
		}
	}
	
	public static MemberDTO getMember(int no){
		SqlSession session = sqlMapper.openSession();
		try{
			MemberDTO dto = session.selectOne("getMember", no);
			return dto;
		}finally{
			session.close();
		}
	}
		
	public static List<MemberDTO> findMember(String search, String searchString){
		SqlSession session = sqlMapper.openSession();
		try{
			java.util.Map<String, String> map = new java.util.Hashtable<>();
			if (search == null || searchString==null){
				search = "";
				searchString = "";
			}
			map.put("search", search);
			map.put("searchString", searchString);
			List<MemberDTO> list = session.selectList("findMember", map);
			return list;
		}finally{
			session.close();
		}
	}
		
	public static boolean checkMember
								(String name, String ssn1, String ssn2){
		SqlSession session = sqlMapper.openSession();
		try{
			java.util.Map<String, String> map = new java.util.Hashtable<>();
			map.put("ssn1", ssn1);
			map.put("ssn2", ssn2);
			MemberDTO dto = session.selectOne("checkMember", map);
			if (dto == null) return false;
			return true;
		}finally{
			session.close();
		}
	}
	
	public static int insertMember(MemberDTO dto){
		SqlSession session = sqlMapper.openSession();
		try{
			int res = session.insert("insertMember", dto);
			session.commit();
			return res;
		}finally{
			session.close();
		}
	}
	  
	public static int deleteMember(int no){
		SqlSession session = sqlMapper.openSession();
		try{
			int res = session.insert("deleteMember", no);
			session.commit();
			return res;
		}finally{
			session.close();
		}
	}
	
	public static int updateMember(MemberDTO dto){
		SqlSession session = sqlMapper.openSession();
		try{
			int res = session.insert("updateMember", dto);
			session.commit();
			return res;
		}finally{
			session.close();
		}
	}
}









