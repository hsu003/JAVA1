package member.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import member.dao.MemberDAO;
import member.dto.MemberDTO;
import mybatis.MemberMapper;

@Controller
public class MemberController {
	
	@Autowired
	private MemberDAO memberDAO;

	@RequestMapping(value = "/member.do")
	public String mainMember(){
		return "main";
	}
	
	@RequestMapping("/memberSsn.do")
	public String memberSsn(){
		return "WEB-INF/member/memberSsn.jsp";
	}
	
	@RequestMapping("/checkMember.do")
	public String checkMember(HttpServletRequest req){
		String name = req.getParameter("name");
		String ssn1 = req.getParameter("ssn1");
		String ssn2 = req.getParameter("ssn2");
		boolean isMember = 
				MemberMapper.checkMember(name, ssn1, ssn2);
		String msg = null, url = null;
		if (isMember){
			msg = "���� ȸ���̽ʴϴ�. �α����� �� �ּ���";
			url = "member.do";
			req.setAttribute("msg", msg);
			req.setAttribute("url",  url);
			return "message.jsp";
		}else {
			req.setAttribute("name", name);
			req.setAttribute("ssn1", ssn1);
			req.setAttribute("ssn2", ssn2);
			return "WEB-INF/member/member_input.jsp";
		}
	}
	
	@RequestMapping("/member_input_ok.do")
	public String memberInput(HttpServletRequest req, MemberDTO dto){
		int res = MemberMapper.insertMember(dto);
		String msg = null, url = null;
		if (res>0){
			msg = "ȸ�����Լ���!! ȸ������������� �̵��մϴ�.";
			url = "memberAll.do";
		}else {
			msg = "ȸ�����Խ���!! ȸ�������������� �̵��մϴ�.";
			url = "member.do";
		}
		req.setAttribute("msg", msg);
		req.setAttribute("url",  url);
		return "message.jsp";
	}
	
	@RequestMapping("/memberAll.do")
	public ModelAndView memberAll(HttpServletRequest req){
		String mode = req.getParameter("mode");
		if (mode == null){
			mode = "all";
		}
		List<MemberDTO> list = null;
		if (mode.equals("all")){
			list = MemberMapper.listMember();
		}else {
			String search = req.getParameter("search");
			String searchString = req.getParameter("searchString");
			list = MemberMapper.findMember(search, searchString);
		}
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("WEB-INF/member/memberAll.jsp");
		mav.addObject("memberList", list);
		mav.addObject("mode", mode);
		return mav;
	}
	
	@RequestMapping("/member_delete.do")
	public ModelAndView memberDelete(@RequestParam int no){
		int res = MemberMapper.deleteMember(no);
		String msg = null, url = null;
		if (res>0){
			msg = "ȸ����������!! ȸ������������� �̵��մϴ�.";
			url = "memberAll.do";
		}else {
			msg = "ȸ����������!! ȸ�������������� �̵��մϴ�.";
			url = "memberAll.do";
		}
		ModelAndView mav = new ModelAndView();
		mav.addObject("msg", msg);
		mav.addObject("url", url);
		mav.setViewName("message.jsp");
		return mav;
	}
	
	@RequestMapping(value="/member_edit.do", method=RequestMethod.GET)
	public ModelAndView memberEdit(@RequestParam int no){
		MemberDTO dto = MemberMapper.getMember(no);
		ModelAndView mav = new ModelAndView
				("WEB-INF/member/member_edit.jsp", "getMember", dto);
		return mav;
	}
	
	@RequestMapping(value="/member_edit.do", method=RequestMethod.POST)
	public ModelAndView memberEditOk
		(@ModelAttribute MemberDTO dto, BindingResult result){
		if(result.hasErrors()){
			dto.setNo(0);
		}
		int res = memberDAO.updateMember(dto);
		String msg = null, url = null;
		if (res>0){
			msg = "ȸ����������!! ȸ������������� �̵��մϴ�.";
			url = "memberAll.do";
		}else {
			msg = "ȸ����������!! ȸ�������������� �̵��մϴ�.";
			url = "memberAll.do";
		}
		ModelAndView mav = new ModelAndView();
		mav.addObject("msg", msg);
		mav.addObject("url", url);
		mav.setViewName("message.jsp");
		return mav;
	}
}









