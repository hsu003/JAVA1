package member.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import member.dao.MemberDAO;
import member.dto.MemberDTO;

public class MemberAllController implements Controller {
	private MemberDAO memberDAO;
	
	public void setMemberDAO(MemberDAO memberDAO) {
		this.memberDAO = memberDAO;
	}

	@Override
	public ModelAndView handleRequest(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception {
		String mode = arg0.getParameter("mode");
		if (mode == null){
			mode = "all";
		}
		List<MemberDTO> list = null;
		if (mode.equals("all")){
			list = memberDAO.listMember();
		}else {
			String search = arg0.getParameter("search");
			String searchString = arg0.getParameter("searchString");
			list = memberDAO.findMember(search, searchString);
		}
		
		ModelAndView mav = new ModelAndView();
		mav.setViewName("WEB-INF/member/memberAll.jsp");
		mav.addObject("memberList", list);
		mav.addObject("mode", mode);
		return mav;
	}

}








