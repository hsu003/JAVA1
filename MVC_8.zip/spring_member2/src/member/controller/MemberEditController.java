package member.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import member.dao.MemberDAO;
import member.dto.MemberDTO;

public class MemberEditController implements Controller {
	private MemberDAO memberDAO;
	
	public void setMemberDAO(MemberDAO memberDAO) {
		this.memberDAO = memberDAO;
	}

	@Override
	public ModelAndView handleRequest(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception {
		String no = arg0.getParameter("no");
		MemberDTO dto = memberDAO.getMember(Integer.parseInt(no));
		ModelAndView mav = new ModelAndView
				("WEB-INF/member/member_edit.jsp", "getMember", dto);
		return mav;
	}

}
