package member.dao;

import java.sql.SQLException;
import java.util.*;
import member.dto.*;

public interface MemberDAO {
	public List<MemberDTO> listMember();
	public List<MemberDTO> findMember(String search, String searchString);
	public MemberDTO getMember(int no);
	public int insertMember(MemberDTO dto);
	public int updateMember(MemberDTO dto);
	public int deleteMember(int no);
	public boolean checkMember(String name, String ssn1, String ssn2);
}
