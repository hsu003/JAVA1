package my.book;

import java.sql.*;
import java.util.*;

public class BookDAO {
	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;
	
	private String url, user, pass;
	
	public BookDAO() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		url = "jdbc:oracle:thin:@localhost:1521:xe";
		user = "javaweb";
		pass = "javaweb";
	}
	
	public boolean checkBookName(String name) throws SQLException {
		try {
			con = DriverManager.getConnection(url, user, pass);
			String sql = "select * from book where name = ?";
			ps = con.prepareStatement(sql);
			ps.setString(1, name);
			rs = ps.executeQuery();
			if (rs.next()) {
				return true;		//�ش��ϴ� �������� �ִ�
			}else {
				return false;	//�ش��ϴ� �������� ����
			}
		}finally {
			if (rs != null) rs.close();
			if (ps != null) ps.close();
			if (con != null) con.close();
		}
	}
	
	public int insertBook(BookDTO dto) throws SQLException{
		try {
			con = DriverManager.getConnection(url, user, pass);
			String sql = "insert into book values(?, ?, ?, ?)";
			ps = con.prepareStatement(sql);
			ps.setString(1, dto.getName());
			ps.setString(2, dto.getPublisher());
			ps.setString(3, dto.getWriter());
			ps.setInt(4, dto.getPrice());
			int res = ps.executeUpdate();
			return res;
		}finally {
			if (ps != null) ps.close();
			if (con != null) con.close();
		}
	}
	
	public List<BookDTO> listBook() throws SQLException {
		try {
			con = DriverManager.getConnection(url, user, pass);
			String sql = "select * from book";
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			List<BookDTO> list = makeList(rs);
			return list;
		}finally {
			if (rs != null) rs.close();
			if (ps != null) ps.close();
			if (con != null) con.close();
		}
	}
	
	public List<BookDTO> makeList(ResultSet rs) throws SQLException {
		List<BookDTO> list = new ArrayList<BookDTO>();
		while(rs.next()) {
			BookDTO dto = new BookDTO();
			dto.setName(rs.getString("name"));
			dto.setPublisher(rs.getString("publisher"));
			dto.setWriter(rs.getString("writer"));
			dto.setPrice(rs.getInt("price"));
			list.add(dto);
		}
		return list;
	}
	
	public int deleteBook(String name) throws SQLException{
		try {
			con = DriverManager.getConnection(url, user, pass);
			String sql = "delete from book where name = ?";
			ps = con.prepareStatement(sql);
			ps.setString(1, name);
			int res = ps.executeUpdate();
			return res;
		}finally {
			if (ps != null) ps.close();
			if (con != null) con.close();
		}
	}
	
	public List<BookDTO> findBook(String search, String searchString)
										throws SQLException {
		try {
			con = DriverManager.getConnection(url, user, pass);
			String sql = "select * from book where  "+search+" like ?";
			ps = con.prepareStatement(sql);
			ps.setString(1, "%"+searchString+"%");
			rs = ps.executeQuery();
			List<BookDTO> find = makeList(rs);
			return find;
		}finally {
			if (rs != null) rs.close();
			if (ps != null) ps.close();
			if (con != null) con.close();
		}
	}
}














