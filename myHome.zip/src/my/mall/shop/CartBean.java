package my.mall.shop;
import java.util.*;

import my.member.MemberDTO;

public class CartBean {
	private Hashtable<String, Cart> ht;

	public CartBean() {
		ht = new Hashtable<>();
	}
	  
	public boolean addCart(String select, String pnum, int pqty) {
		if (ht.containsKey(pnum)) {
			Cart cart = ht.get(pnum);
			cart.setPqty(cart.getPqty()+pqty);
		}else {
			ht.put(pnum, new Cart(select, pqty));
		}
		return true;
	}
	
	public Hashtable<String, Cart> listCart(){
		return ht;
	}
	
	public void editCart(String pnum, int pqty) {
		Cart cart = ht.get(pnum);
		cart.setPqty(pqty);
		if (cart.getPqty()<1) deleteCart(pnum);
	}
	
	public void deleteCart(String pnum) {
		ht.remove(pnum);	
	}
	

}
