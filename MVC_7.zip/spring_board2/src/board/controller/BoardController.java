package board.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import board.dao.BoardDAO;
import board.dto.BoardDTO;

@Controller
public class BoardController {
	@Autowired
	private BoardDAO boardDAO;
	
	@RequestMapping("/")
	public String start(){
		return "redirect:list";
	}
	
	@RequestMapping("/list")
	public void listBoard(HttpServletRequest req){
		List<BoardDTO> list = boardDAO.listBoard();
		req.setAttribute("boardList", list);
	}
	
	@RequestMapping("/writeForm")
	public void writeFormBoard(){
	}
	
	@RequestMapping("/writePro")
	public String writeProBoard(HttpServletRequest req,
			@ModelAttribute BoardDTO dto, BindingResult result) throws IOException{
		if(result.hasErrors()){
			dto.setFilename("");
			dto.setFilesize(0);
		}
		
		MultipartHttpServletRequest mr = (MultipartHttpServletRequest)req;
		MultipartFile mf = mr.getFile("filename");
		String filename = mf.getOriginalFilename();
		
		if (filename != null && !(filename.trim().equals(""))){
			HttpSession session = req.getSession();
			String upPath = session.getServletContext().getRealPath("files");
			File file = new File(upPath, filename);
			mf.transferTo(file);
			dto.setFilename(filename);
			dto.setFilesize((int)file.length());
		}else {
			dto.setFilename("");
			dto.setFilesize(0);
		}
		
		dto.setIp(req.getRemoteAddr());
		boardDAO.insertBoard(dto);
		return "redirect:list";
	}
	
	@RequestMapping("/content")
	public void contentBoard(HttpServletRequest req, @RequestParam int num){
		boardDAO.plusReadcount(num);
		BoardDTO dto = boardDAO.getBoard(num);
		req.setAttribute("getBoard", dto);
		String upPath = req.getServletContext().getRealPath("/files");
		req.setAttribute("upPath", upPath);
	}
}











