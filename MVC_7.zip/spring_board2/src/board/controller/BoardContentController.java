package board.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import board.dao.BoardDAO;
import board.dto.BoardDTO;

public class BoardContentController implements Controller {
	private BoardDAO boardDAO;
	
	public void setBoardDAO(BoardDAO boardDAO) {
		this.boardDAO = boardDAO;
	}

	@Override
	public ModelAndView handleRequest(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception {
		String num = arg0.getParameter("num");
		boardDAO.plusReadcount(Integer.parseInt(num));
		BoardDTO dto = boardDAO.getBoard(Integer.parseInt(num));
		//ModelAndView mav = new ModelAndView("�̵���������", "Ű", "value");
		return new ModelAndView("content", "getBoard", dto);
	}

}
