package login;

public class LoginFactory {
	private LoginFactory() {}
	private static LoginFactory instance = new LoginFactory();
	public static LoginFactory getInstance() {
		return instance;
	}
	
	public CommandIf createCommand(String cmd) {
		CommandIf cmdIf = null;
		if (cmd.equals("/login.log")) {
			cmdIf = new LoginCommand();
		}else if (cmd.equals("/login_ok.log")) {
			cmdIf = new LoginOkCommand();
		}
		return cmdIf;
	}
}
