package book;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ListBookCommand implements CommandIf {

	@Override
	public Object processCommand(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		BookDAO dao = new BookDAO();
		List<BookDTO> list = null;
		try{
			list = dao.listBook();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		req.setAttribute("bookList", list);
		return "WEB-INF/jsp/book/list.jsp";    //���� ȭ�鿡 �����ִ� �������� �;� �Ѵ�.
	}

}











