package book;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FindBookCommand implements CommandIf {

	@Override
	public Object processCommand(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String search = req.getParameter("search");
		String searchString = req.getParameter("searchString");
		BookDAO dao = new BookDAO();
		List<BookDTO> find = null;
		try {
			find = dao.findBook(search, searchString);  //�ٿ����� �Ѱܹ��� ���� ����� �¸޼ҵ带 ȣ�� �ϱ�.
		}catch(SQLException e) {
			e.printStackTrace();
		}
		req.setAttribute("bookList", find);
		return "WEB-INF/jsp/book/list.jsp";
	}

}
