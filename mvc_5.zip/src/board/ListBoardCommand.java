package board;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ListBoardCommand implements CommandIf {

	@Override
	public Object processCommand(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		BoardDataBean dao = new BoardDataBean();
		int pageSize = 5;
		String pageNum = req.getParameter("pageNum");
		if (pageNum == null){
			pageNum = "1";
		}
		int currentPage = Integer.parseInt(pageNum);
		int startRow = currentPage * pageSize - (pageSize-1);
		int endRow = currentPage * pageSize;
		int count = 0;
		try{
			count = dao.getCount();    
		}catch(SQLException e) {
			e.printStackTrace();
		}
		if (endRow>count) endRow = count;
		
		List<BoardDBBean> list = null;
		try{
			list = dao.listBoard(startRow, endRow);
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		int startNum = count - ((currentPage-1) * pageSize); 
		
		
		int pageCount = count/pageSize + (count%pageSize == 0 ? 0 : 1);
		int pageBlock = 3;
		int startPage = (currentPage-1)/pageBlock * pageBlock + 1;
		int endPage = startPage + pageBlock - 1;
		if (endPage>pageCount) endPage = pageCount;
		
		
		
		req.setAttribute("count", count);
		req.setAttribute("startNum", startNum);
		req.setAttribute("pageCount", pageCount);
		req.setAttribute("pageBlock", pageBlock);
		req.setAttribute("startPage", startPage);
		req.setAttribute("endPage", endPage);
		req.setAttribute("listBoard", list);
		return "WEB-INF/jsp/board/list.jsp";		
	}

}














