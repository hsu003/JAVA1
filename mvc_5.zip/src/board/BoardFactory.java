package board;

public class BoardFactory {
	private BoardFactory() {}
	private static BoardFactory instance = new BoardFactory();
	public static BoardFactory getIntance() {
		return instance;
	}
	
	public CommandIf createCommand(String cmd) {
		CommandIf cmdIf = null;
		//cmd������ �ش� Ŭ������ ����� �ش�
		if (cmd.equals("/list.board")) {
			cmdIf = new ListBoardCommand();
		}else if (cmd.equals("/writeForm.board")) {
			cmdIf = new WriteFormBoardCommand();
		}else if (cmd.equals("/writePro.board")) {
			cmdIf = new WriteProBoardCommand();
		}else if (cmd.equals("/content.board")) {
			cmdIf = new ContentBoardCommand();
		}else if (cmd.equals("/deleteForm.board")) {
			cmdIf = new DeleteFormBoardCommand();
		}else if (cmd.equals("/deletePro.board")) {
			cmdIf = new DeleteProBoardCommand();
		}else if (cmd.equals("/updatForm.board")) {
			cmdIf = new UpdateFormBoardCommand();
		}else if (cmd.equals("/updatePro.board")) {
			cmdIf = new UpdateProBoardCommand();
		}
		return cmdIf;
	}
}












