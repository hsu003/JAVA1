package board2;

public class Board2Factory {
	private Board2Factory() {}
	private static Board2Factory instance = new Board2Factory();
	public static Board2Factory getInstance() {
		return instance;
	}
	
	public CommandIf createCommand(String cmd) {
		CommandIf cmdIf = null;
		if (cmd.equals("/list.board2")) {
			cmdIf = new ListBoard2Command();
		}else if (cmd.equals("/writeForm.board2")) {
			cmdIf = new WriteFormBoard2Command();
		}else if (cmd.equals("/writePro.board2")) {
			cmdIf = new WriteProBoard2Command();
		}else if (cmd.equals("/content.board2")) {
			cmdIf = new ContentBoard2Command();
		}
		return cmdIf;
	}
}
