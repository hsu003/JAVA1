package board2;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ContentBoard2Command implements CommandIf {

	@Override
	public Object processCommand(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String num = req.getParameter("num");
		BoardDAO dao = new BoardDAO();
		BoardDTO dto = null;
		try {
			dao.readCount(Integer.parseInt(num));
			dto = dao.getBoard(Integer.parseInt(num));
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		req.setAttribute("getBoard", dto);
		return "WEB-INF/jsp/board2/content.jsp";
	}

}










