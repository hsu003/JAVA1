package board2;

import java.io.IOException;
import java.sql.SQLException;

import com.oreilly.servlet.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class WriteProBoard2Command implements CommandIf {

	@Override
	public Object processCommand(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		MultipartRequest mr = null;
		String upPath = req.getServletContext().getRealPath("/files");
		try {
			mr = new MultipartRequest(req, upPath, 10*1024*1024, "EUC-KR");
		}catch(IOException e) {
			e.printStackTrace();
		}
		BoardDAO dao = new BoardDAO();
		int res = 0;
		try {
			res = dao.insertBoard(mr, req.getRemoteAddr());
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		String msg = null, url = null;
		if (res>0) {
			msg = "�Խñ۵�ϼ���!! �Խñ۸���������� �̵��մϴ�.";
			url = "list.board2";
		}else {
			msg = "�Խñ۵�Ͻ���!! �Խñ۵���������� �̵��մϴ�.";
			url = "writeForm.board2";
		}
		req.setAttribute("msg", msg);
		req.setAttribute("url", url);
		return "message.jsp";
	}

}









