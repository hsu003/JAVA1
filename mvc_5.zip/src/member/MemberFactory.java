package member;

public class MemberFactory {
	private MemberFactory() {}
	private static MemberFactory instance = new MemberFactory();
	public static MemberFactory getInstance() {
		return instance;
	}
	
	public CommandIf createCommand(String cmd) {
		CommandIf cmdIf = null;
		if (cmd.equals("/index.mem")) {
			cmdIf = new IndexMemberCommand();
		}else if (cmd.equals("/memberSsn.mem")) {
			cmdIf = new MemberSsnCommand();
		}else if (cmd.equals("/checkMember.mem")) {
			cmdIf = new CheckMemberCommand();
		}else if (cmd.equals("/member_input.mem")) {
			cmdIf = new MemberInputCommand();
		}else if (cmd.equals("/member_input_ok.mem")) {
			cmdIf = new MemberInputOkCommand();
		}else if (cmd.equals("/memberAll.mem")) {
			cmdIf = new MemberAllCommand();
		}else if (cmd.equals("/member_delete.mem")) {
			cmdIf = new MemberDeleteCommand();
		}else if (cmd.equals("/member_edit.mem")) {
			cmdIf = new MemberEditCommand();
		}else if (cmd.equals("/member_edit_ok.mem")) {
			cmdIf = new MemberEditOkCommand();
		}
		
		return cmdIf;
	}
}
