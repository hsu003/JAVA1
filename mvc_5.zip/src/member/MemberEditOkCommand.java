package member;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MemberEditOkCommand implements CommandIf {

	@Override
	public Object processCommand(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		MemberDTO dto = new MemberDTO();
		dto.setPasswd(req.getParameter("passwd"));
		dto.setEmail(req.getParameter("email"));
		dto.setHp1(req.getParameter("hp1"));
		dto.setHp2(req.getParameter("hp2"));
		dto.setHp3(req.getParameter("hp3"));
		dto.setNo(Integer.parseInt(req.getParameter("no")));
		MemberDAO dao = new MemberDAO();
		int res = 0;
		try {
			res = dao.updateMember(dto);
		}catch(SQLException e) {
			e.printStackTrace();
		}
		String msg = null, url = "memberAll.mem";
		if (res>0) {
			msg = "ȸ����������!! ȸ�������������� �̵��մϴ�.";
		}else {
			msg = "ȸ����������!! ȸ�������������� �̵��մϴ�.";
		}
		req.setAttribute("msg", msg);
		req.setAttribute("url", url);
		return "message.jsp";
	}

}
