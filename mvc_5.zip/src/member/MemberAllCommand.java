package member;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MemberAllCommand implements CommandIf {

	@Override
	public Object processCommand(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String mode = req.getParameter("mode");
		if (mode==null) {
			mode = "all";
		}
		MemberDAO dao = new MemberDAO();
		List<MemberDTO> list = null;
		try {
			if (mode.equals("all")) {
				list = dao.listMember();
			}else {
				dao.setSearch(req.getParameter("search"));
				dao.setSearchString(req.getParameter("searchString"));
				list = dao.findMember();
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		req.setAttribute("memberList", list);
		req.setAttribute("mode", mode);
		return "WEB-INF/jsp/member/memberAll.jsp";
	}

}







