package shop;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ProdListCommand implements CommandIf {

	@Override
	public Object processCommand(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		ProductBean dao = new ProductBean();
		List<ProductDTO> plist = null;
		try {
			plist = dao.listProduct();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		req.setAttribute("prodList", plist);
		return "WEB-INF/jsp/shop/admin/prod_list.jsp";
	}

}













