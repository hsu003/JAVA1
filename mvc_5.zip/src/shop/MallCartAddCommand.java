package shop;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class MallCartAddCommand implements CommandIf {

	@Override
	public Object processCommand(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String pnum = req.getParameter("pnum");
		String select = req.getParameter("select");
		String pqty = req.getParameter("pqty");
		
		HttpSession session = req.getSession();
		CartBean cart = (CartBean)session.getAttribute("cart");
		if (cart == null) {
			cart = new CartBean();
		}
		
		String msg = null, url = null;
		if (Integer.parseInt(pqty)<1){
			msg = "�ֹ������� ��� ���θ� ������������ �̵��մϴ�.";
			url = "shop_mall.mall";
		}else {
			boolean isAdd = cart.addCart(select, pnum, Integer.parseInt(pqty)); 
			if (isAdd){
				msg = "��ٱ��� �������� �̵��մϴ�.";
				url = "mall_cartList.mall";
			}else{
				msg = "��ٱ��� ��� ����!!";
				url = "mall.jsp";
			}
		}
		req.setAttribute("msg", msg);
		req.setAttribute("url", url);
		session.setAttribute("cart", cart);
		return "message.jsp";
		
	}
}
