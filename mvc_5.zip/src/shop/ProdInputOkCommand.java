package shop;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.*;

public class ProdInputOkCommand implements CommandIf {

	@Override
	public Object processCommand(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		MultipartRequest mr = null;
		String upPath = req.getServletContext().getRealPath("files");
		try {
			mr = new MultipartRequest(req, upPath, 10*1024*1024, "EUC-KR");
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		int res = 0;
		ProductBean dao = new ProductBean();
		try {
			res = dao.insertProduct(mr);
		}catch(SQLException e) {
			e.printStackTrace();
		}
		String msg = null, url = null;
		if (res>0) {
			msg = "��ǰ�Է¼���!! ��ǰ����������� �̵��մϴ�.";
			url = "prod_list.mall";
		}else {
			msg = "��ǰ�Է½���!! ��ǰ�Է��������� �̵��մϴ�.";
			url = "prod_input.mall";
		}
		req.setAttribute("msg", msg);
		req.setAttribute("url", url);
		return "message.jsp";
	}

}














