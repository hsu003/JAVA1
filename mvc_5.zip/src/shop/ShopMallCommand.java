package shop;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ShopMallCommand implements CommandIf {

	@Override
	public Object processCommand(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		CategoryBean cdao = new CategoryBean();
		List<CategoryDTO> clist = null;
		HttpSession session = req.getSession();
		ProductList proList = (ProductList)session.getAttribute("proList");
		if (proList == null) {
			proList = new ProductList();
		}
		try {
			clist = cdao.listCategory();
			List<ProductDTO> hit = proList.selectBySpec("hit");
			List<ProductDTO> best = proList.selectBySpec("best");
			List<ProductDTO> new1 = proList.selectBySpec("new");
			session.setAttribute("hit", hit);
			session.setAttribute("best", best);
			session.setAttribute("new", new1);
		}catch(SQLException e) {
			e.printStackTrace();
		}
		session.setAttribute("proList", proList);
		session.setAttribute("cateList", clist);
		return "WEB-INF/jsp/shop/display/mall.jsp";
	}

}









