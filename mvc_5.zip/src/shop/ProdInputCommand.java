package shop;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ProdInputCommand implements CommandIf {

	@Override
	public Object processCommand(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		CategoryBean dao = new CategoryBean();
		List<CategoryDTO> clist = null;
		try{
			clist = dao.listCategory();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		req.setAttribute("cateList", clist);
		return "WEB-INF/jsp/shop/admin/prod_input.jsp";
	}

}















