package shop;

public class ShopAdminFactory {
	private ShopAdminFactory() {}
	private static ShopAdminFactory instance = new ShopAdminFactory();
	public static ShopAdminFactory getInstance() {
		return instance;
	}
	
	public CommandIf createCommand(String cmd) {
		CommandIf cmdIf = null;
		if (cmd.equals("/shopAdmin.mall")) {
			cmdIf = new ShopAdminCommand();
		}else if (cmd.equals("/cate_input.mall")) {
			cmdIf = new CateInputCommand();
		}else if (cmd.equals("/cate_input_ok.mall")) {
			cmdIf = new CateInputOkCommand();
		}else if (cmd.equals("/cate_list.mall")) {
			cmdIf = new CategoryListCommand();
		}else if (cmd.equals("/cate_delete.mall")) {
			cmdIf = new CategoryDeleteCommand();
		}else if (cmd.equals("/prod_input.mall")) {
			cmdIf = new ProdInputCommand();
		}else if (cmd.equals("/prod_input_ok.mall")) {
			cmdIf = new ProdInputOkCommand();
		}else if (cmd.equals("/prod_list.mall")) {
			cmdIf = new ProdListCommand();
		}else if (cmd.equals("/prod_view.mall")) {
			cmdIf = new ProdViewCommand();
		}else if (cmd.equals("/prod_delete.mall")) {
			cmdIf = new ProdDeleteCommand();
		}else if (cmd.equals("/prod_update.mall")) {
			cmdIf = new ProdUpdateCommand();
		}else if (cmd.equals("/prod_update_ok.mall")) {
			cmdIf = new ProdUpdateOkCommand();
		}else if (cmd.equals("/shop_mall.mall")) {
			cmdIf = new ShopMallCommand();
		}else if (cmd.equals("/mall_cgProdList.mall")) {
			cmdIf = new MallcgProdListCommand();
		}else if (cmd.equals("/mall_prodView.mall")) {
			cmdIf = new MallProdViewCommand();
		}else if (cmd.equals("/mall_cartAdd.mall")) {
			cmdIf = new MallCartAddCommand();
		}else if (cmd.equals("/mall_cartList.mall")) {
			cmdIf = new MallCartListCommand();
		}else if (cmd.equals("/mall_cartEdit.mall")) {
			cmdIf = new MallCartEditCommand();
		}else if (cmd.equals("/mall_cartDel.mall")) {
			cmdIf = new MallCartDelCommand();
		}
		return cmdIf;
	}
}







