package shop;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CategoryListCommand implements CommandIf {

	@Override
	public Object processCommand(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		CategoryBean dao = new CategoryBean();
		List<CategoryDTO> list = null;
		try {
			list = dao.listCategory();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		req.setAttribute("cateList", list);
		return "WEB-INF/jsp/shop/admin/cate_list.jsp";
	}

}











