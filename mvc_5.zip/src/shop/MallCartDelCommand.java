package shop;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class MallCartDelCommand implements CommandIf {

	@Override
	public Object processCommand(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String pnum = req.getParameter("pnum");
		
		HttpSession session = req.getSession();
		CartBean cart = (CartBean)session.getAttribute("cart");
		if (cart == null) {
			cart = new CartBean();
		}
		
		cart.deleteCart(pnum);
		return "mall_cartList.mall";
	}

}
