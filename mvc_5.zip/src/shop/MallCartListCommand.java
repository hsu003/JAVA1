package shop;

import java.io.IOException;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class MallCartListCommand implements CommandIf {

	@Override
	public Object processCommand(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		HttpSession session = req.getSession();
		CartBean cart = (CartBean)session.getAttribute("cart");
		if (cart == null) {
			cart = new CartBean();
		}
		ProductList proList = (ProductList)session.getAttribute("proList");
		Hashtable<String, Cart> ht = cart.listCart();
		Enumeration<String> enu = ht.keys();
		List<ProductDTO> list = new ArrayList<ProductDTO>();
		while(enu.hasMoreElements()){
			String pnum = enu.nextElement();	
			Cart ct = ht.get(pnum);
			ProductDTO dto = proList.getProduct(ct.getSelect(), Integer.parseInt(pnum));
			dto.setPqty(ct.getPqty());
			list.add(dto);
		}
		req.setAttribute("cart", list);
		return "WEB-INF/jsp/shop/display/mall_cartList.jsp";
	}

}














