package shop;

public class Cart {
	private String select;
	private int pqty;
	
	public Cart(String select, int pqty) {
		this.select = select;
		this.pqty = pqty;
	}
	
	public String getSelect() {
		return select;
	}
	public void setSelect(String select) {
		this.select = select;
	}
	public int getPqty() {
		return pqty;
	}
	public void setPqty(int pqty) {
		this.pqty = pqty;
	}
}
