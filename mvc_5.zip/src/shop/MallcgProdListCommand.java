package shop;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class MallcgProdListCommand implements CommandIf {

	@Override
	public Object processCommand(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String code = req.getParameter("code");
		CategoryBean cdao = new CategoryBean();
		HttpSession session = req.getSession();
		ProductList proList = (ProductList)session.getAttribute("proList");
		if (proList == null) {
			proList = new ProductList();
		}
		try {
			List<ProductDTO> codeList = proList.selectByCode(code);
			session.setAttribute(code, codeList); 
			//req.setAttribute("code", code);
			String cname = cdao.getName(code);
			req.setAttribute("cname", cname);
		}catch(SQLException e) {
			e.printStackTrace();
		}
		session.setAttribute("proList", proList);
		return "WEB-INF/jsp/shop/display/mall_cgProdList.jsp";
	}

}
