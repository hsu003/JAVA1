package board.mybatis;

import java.io.*;
import java.util.*;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import board.dto.BoardDTO;

public class BoardMapper {
	private static SqlSessionFactory sqlMapper;
	
	static{
		try{
			String resource = "board/mybatis/configuration.xml";
			Reader reader = Resources.getResourceAsReader(resource);
			sqlMapper = new SqlSessionFactoryBuilder().build(reader);
		}catch(IOException e){
			throw new RuntimeException
			("myBatis�� ���������� �ø��µ� �����Ͽ����ϴ�." + e, e);
		}
	}
	
	public static List<BoardDTO> listBoard(int start, int end){
		SqlSession session = sqlMapper.openSession();
		try{
			Map<String, Integer> map = new Hashtable<>();
			map.put("start" , start);
			map.put("end", end);
			List<BoardDTO> list = session.selectList("listBoard", map);
			return list;
		}finally{
			session.close();
		}
	}
	
	public static int getCount(){
		SqlSession session = sqlMapper.openSession();
		try{
			Integer count = session.selectOne("getCount");
			return count;
		}finally{
			session.close();
		}
	}
	
	public static int insertBord(BoardDTO dto){
		SqlSession session = sqlMapper.openSession();
		try{
			if (dto.getNum()==0){
				Integer num = session.selectOne("maxNum");
				if (num == null){
					dto.setRe_group(1);
				}else {
					dto.setRe_group(num + 1);
				}
			}else {
				Map<String, Integer> map = new Hashtable<>();
				map.put("re_step", dto.getRe_step());
				map.put("re_group", dto.getRe_group());
				int res = session.update("plusRe_step", map);
				dto.setRe_step(dto.getRe_step() + 1);
				dto.setRe_level(dto.getRe_level() + 1);
			}
			int res = session.insert("insertBoard", dto);
			session.commit();
			return res;
		}finally{
			session.close();
		}
	}
	
	public static boolean isPassword(int num, String passwd){
		SqlSession session = sqlMapper.openSession();
		try{
			String dbPass = session.selectOne("isPassword", num);
			if (dbPass.equals(passwd)) return true;
			else return false;
		}finally{
			session.close();
		}
	}
	
	public static BoardDTO getBoard(int num){
		SqlSession session = sqlMapper.openSession();
		try{
			BoardDTO dto = session.selectOne("getBoard", num);
			return dto;
		}finally{
			session.close();
		}
	}
	
	public static int plusReadcount(int num){
		SqlSession session = sqlMapper.openSession();
		try{
			int res = session.update("plusReadcount", num);
			session.commit();
			return res;
		}finally{
			session.close();
		}
	}
	
	public static int deleteBoard(int num){
		SqlSession session = sqlMapper.openSession();
		try{
			int res = session.delete("deleteBoard", num);
			session.commit();
			return res;
		}finally{
			session.close();
		}
	}
	
	public static int updateBoard(BoardDTO dto){
		SqlSession session = sqlMapper.openSession();
		try{
			int res = session.update("updateBoard", dto);
			session.commit();
			return res;
		}finally{
			session.close();
		}
	}
	/*
	
		
	public static List<MemberDTO> findMember(String search, String searchString){
		SqlSession session = sqlMapper.openSession();
		try{
			java.util.Map<String, String> map = new java.util.Hashtable<>();
			if (search == null || searchString==null){
				search = "";
				searchString = "";
			}
			map.put("search", search);
			map.put("searchString", searchString);
			List<MemberDTO> list = session.selectList("findMember", map);
			return list;
		}finally{
			session.close();
		}
	}
		
	public static boolean checkMember
								(String name, String ssn1, String ssn2){
		SqlSession session = sqlMapper.openSession();
		try{
			java.util.Map<String, String> map = new java.util.Hashtable<>();
			map.put("ssn1", ssn1);
			map.put("ssn2", ssn2);
			MemberDTO dto = session.selectOne("checkMember", map);
			if (dto == null) return false;
			return true;
		}finally{
			session.close();
		}
	}
	
	public static int insertMember(MemberDTO dto){
		SqlSession session = sqlMapper.openSession();
		try{
			int res = session.insert("insertMember", dto);
			session.commit();
			return res;
		}finally{
			session.close();
		}
	}
	  
	
	
	
	*/
}









