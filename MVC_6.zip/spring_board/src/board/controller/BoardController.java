package board.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import board.dao.BoardDAO;
import board.dto.BoardDTO;
import board.mybatis.BoardMapper;

@Controller
public class BoardController {

	@Autowired
	private BoardDAO boardDAO;
	
	@RequestMapping("/board_list.do")
	public String list(HttpServletRequest req){
		String pageNum = req.getParameter("pageNum");
		if (pageNum==null){
			pageNum = "1";
		}
		int pageSize = 5;
		int currentPage = Integer.parseInt(pageNum);
		int startRow = currentPage * pageSize - (pageSize-1);
		int endRow = currentPage * pageSize;
		int count = BoardMapper.getCount();
		if (endRow>count) endRow = count;
		int startNum = count - ((currentPage-1) * pageSize); 
		List<BoardDTO> list = BoardMapper.listBoard(startRow, endRow);
		req.setAttribute("boardList", list);
		req.setAttribute("startNum", startNum);
		if (count>0){
			int pageCount = count/pageSize + (count%pageSize == 0 ? 0 : 1);
			int pageBlock = 3;
			int startPage = (currentPage-1)/pageBlock * pageBlock + 1;
			int endPage = startPage + pageBlock - 1;
			if (endPage>pageCount) endPage = pageCount;
			req.setAttribute("count", count);
			req.setAttribute("pageCount", pageCount);
			req.setAttribute("pageBlock", pageBlock);
			req.setAttribute("startPage", startPage);
			req.setAttribute("endPage", endPage);
		}
		return "list";
	}
	
	@RequestMapping(value="/board_write.do", method=RequestMethod.GET)
	public String writeForm(){
		return "writeForm";
	}
	
	@RequestMapping(value="/board_write.do", method=RequestMethod.POST)
	public ModelAndView writePro(HttpServletRequest req, 
			@ModelAttribute BoardDTO dto,	BindingResult result){
		
		if (result.hasErrors()){
			dto.setNum(0);
			dto.setRe_group(0);
			dto.setRe_step(0);
			dto.setRe_level(0);
		}
		dto.setIp(req.getRemoteAddr());
		int res = BoardMapper.insertBord(dto);
		String msg = null, url = null;
		if (res>0){
			msg = "�Խñ� ��� ����!! �Խñ� ����������� �̵��մϴ�.";
			url = "board_list.do";
		}else {
			msg = "�Խñ� ��� ����!! �Խñ� ����������� �̵��մϴ�.";
			url = "board_write.do";
		}
		req.setAttribute("msg", msg);
		req.setAttribute("url", url);
		return new ModelAndView("forward:message.jsp");
	}
	
	@RequestMapping("/board_content.do")
	public String content(HttpServletRequest req, @RequestParam int num){
		BoardMapper.plusReadcount(num);
		BoardDTO dto = BoardMapper.getBoard(num);
		req.setAttribute("getBoard", dto);
		return "content";
	}
	
	@RequestMapping(value="/board_delete.do", method=RequestMethod.GET)
	public String deleteForm(){
		return "deleteForm";
	}
	
	@RequestMapping(value="/board_delete.do", method=RequestMethod.POST)
	public ModelAndView deletePro(@RequestParam int num, @RequestParam String passwd){
		if (BoardMapper.isPassword(num, passwd)){
			int res = BoardMapper.deleteBoard(num);
		}
		return new ModelAndView("redirect:board_list.do");
	}
	
	@RequestMapping(value="/board_update.do", method=RequestMethod.GET)
	public ModelAndView updateForm(@RequestParam int num){
		BoardDTO dto = BoardMapper.getBoard(num);
		return new ModelAndView("updateForm", "getBoard", dto);
	}
	
	@RequestMapping(value="/board_update.do", method=RequestMethod.POST)
	public String updatePro(BoardDTO dto){
		if (BoardMapper.isPassword(dto.getNum(), dto.getPasswd())){
			int res = BoardMapper.updateBoard(dto);
		}
		return "redirect:board_list.do";
	}
}













