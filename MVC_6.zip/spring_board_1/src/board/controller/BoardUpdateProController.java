package board.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import board.dao.BoardDAO;
import board.dto.BoardDTO;

public class BoardUpdateProController implements Controller {
	private BoardDAO boardDAO;
	public void setBoardDAO(BoardDAO boardDAO) {
		this.boardDAO = boardDAO;
	}

	@Override
	public ModelAndView handleRequest(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception {
		BoardDTO dto = new BoardDTO();
		dto.setWriter(arg0.getParameter("writer"));
		dto.setEmail(arg0.getParameter("email"));
		dto.setSubject(arg0.getParameter("subject"));
		dto.setPasswd(arg0.getParameter("passwd"));
		dto.setContent(arg0.getParameter("content"));
		dto.setNum(Integer.parseInt(arg0.getParameter("num")));
		int res = boardDAO.updateBoard(dto);
		
		return new ModelAndView("redirect:board_list.do");
	}

}









